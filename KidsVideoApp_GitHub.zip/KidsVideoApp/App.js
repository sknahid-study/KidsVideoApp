import React, { useEffect, useState } from 'react';
import {
  View,
  StyleSheet,
  StatusBar,
  Animated,
  Easing,
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import MainNavigator from './src/navigation/MainNavigator';
import SplashScreen from './src/screens/SplashScreen';

export default function App() {
  const [showSplash, setShowSplash] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 2800);
    return () => clearTimeout(timer);
  }, []);

  return (
    <SafeAreaProvider>
      <StatusBar
        barStyle="light-content"
        backgroundColor="#000000"
        translucent={false}
      />
      {showSplash ? (
        <SplashScreen />
      ) : (
        <NavigationContainer
          theme={{
            dark: true,
            colors: {
              primary: '#FF0000',
              background: '#0F0F0F',
              card: '#0F0F0F',
              text: '#FFFFFF',
              border: '#272727',
              notification: '#FF0000',
            },
          }}>
          <MainNavigator />
        </NavigationContainer>
      )}
    </SafeAreaProvider>
  );
}
