import React, { useEffect, useState, useCallback, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  ScrollView,
  Image,
  ActivityIndicator,
  RefreshControl,
  Alert,
  Dimensions,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import Svg, { Path, Rect, Circle } from 'react-native-svg';
import {
  scanAllVideos,
  requestStoragePermission,
  formatDuration,
} from '../utils/VideoUtils';
import AsyncStorage from '@react-native-async-storage/async-storage';

const { width } = Dimensions.get('window');

// YouTube top header logo
const YTLogo = () => (
  <View style={styles.logoRow}>
    <Svg width="28" height="20" viewBox="0 0 90 63">
      <Rect x="0" y="0" width="90" height="63" rx="14" ry="14" fill="#FF0000" />
      <Path d="M 36 16 L 36 47 L 62 31.5 Z" fill="#FFFFFF" />
    </Svg>
    <Text style={styles.logoText}>YouTube</Text>
  </View>
);

// Cast icon
const CastIcon = () => (
  <Svg width="24" height="24" viewBox="0 0 24 24" fill="#FFFFFF">
    <Path d="M21 3H3c-1.1 0-2 .9-2 2v3h2V5h18v14h-7v2h7c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM1 18v3h3c0-1.66-1.34-3-3-3zm0-4v2c2.76 0 5 2.24 5 5h2c0-3.87-3.13-7-7-7zm0-4v2c4.97 0 9 4.03 9 9h2c0-6.08-4.93-11-11-11z" />
  </Svg>
);

// Bell icon
const BellIcon = () => (
  <Svg width="24" height="24" viewBox="0 0 24 24" fill="#FFFFFF">
    <Path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.9 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z" />
  </Svg>
);

// Search icon
const SearchIcon = () => (
  <Svg width="24" height="24" viewBox="0 0 24 24" fill="#FFFFFF">
    <Path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z" />
  </Svg>
);

const CATEGORIES = ['All', 'New to you', 'Music', 'Gaming', 'Movies', 'Kids'];

// Video thumbnail placeholder with play icon
const VideoThumbnail = ({ video, onPress, style }) => {
  const [thumbError, setThumbError] = useState(false);

  return (
    <TouchableOpacity style={[styles.videoCard, style]} onPress={onPress} activeOpacity={0.8}>
      <View style={styles.thumbnailContainer}>
        {!thumbError ? (
          <Image
            source={{ uri: video.thumbnail || video.uri }}
            style={styles.thumbnail}
            onError={() => setThumbError(true)}
          />
        ) : (
          <View style={[styles.thumbnail, styles.thumbPlaceholder]}>
            <Svg width="48" height="34" viewBox="0 0 90 63">
              <Rect x="0" y="0" width="90" height="63" rx="10" fill="#FF0000" opacity="0.7" />
              <Path d="M 36 16 L 36 47 L 62 31.5 Z" fill="#FFFFFF" />
            </Svg>
          </View>
        )}
        {video.duration > 0 && (
          <View style={styles.durationBadge}>
            <Text style={styles.durationText}>{formatDuration(video.duration)}</Text>
          </View>
        )}
      </View>

      <View style={styles.videoInfo}>
        <View style={styles.channelAvatar}>
          <Text style={styles.avatarLetter}>
            {(video.folderName || 'V')[0].toUpperCase()}
          </Text>
        </View>
        <View style={styles.videoMeta}>
          <Text style={styles.videoTitle} numberOfLines={2}>
            {video.title}
          </Text>
          <Text style={styles.videoSubtitle} numberOfLines={1}>
            {video.folderName} · {video.sizeFormatted} · {video.timeAgo}
          </Text>
        </View>
        <TouchableOpacity style={styles.moreBtn}>
          <Text style={styles.moreDots}>⋮</Text>
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );
};

// Shorts card
const ShortsCard = ({ video, onPress }) => (
  <TouchableOpacity style={styles.shortsCard} onPress={onPress} activeOpacity={0.8}>
    <View style={styles.shortsThumb}>
      <Image
        source={{ uri: video.uri }}
        style={styles.shortsThumbImg}
        onError={() => {}}
      />
      <View style={[styles.shortsThumb, styles.shortsThumbFallback]}>
        <Svg width="28" height="20" viewBox="0 0 90 63">
          <Rect x="0" y="0" width="90" height="63" rx="10" fill="#FF0000" opacity="0.6" />
          <Path d="M 36 16 L 36 47 L 62 31.5 Z" fill="#FFFFFF" />
        </Svg>
      </View>
    </View>
    <Text style={styles.shortsTitle} numberOfLines={2}>{video.title}</Text>
  </TouchableOpacity>
);

export default function HomeScreen({ navigation }) {
  const [videos, setVideos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [permissionGranted, setPermissionGranted] = useState(false);

  const loadVideos = async (isRefresh = false) => {
    if (!isRefresh) setLoading(true);

    const hasPermission = await requestStoragePermission();
    setPermissionGranted(hasPermission);

    if (!hasPermission) {
      setLoading(false);
      setRefreshing(false);
      Alert.alert(
        'Permission Required',
        'Storage permission is needed to load videos from your device.',
        [{ text: 'OK' }],
      );
      return;
    }

    try {
      // Try cached first
      if (!isRefresh) {
        const cached = await AsyncStorage.getItem('video_cache');
        if (cached) {
          setVideos(JSON.parse(cached));
          setLoading(false);
        }
      }

      const allVideos = await scanAllVideos();
      setVideos(allVideos);
      await AsyncStorage.setItem('video_cache', JSON.stringify(allVideos.slice(0, 200)));
    } catch (e) {
      console.error('Error loading videos:', e);
    }

    setLoading(false);
    setRefreshing(false);
  };

  useFocusEffect(
    useCallback(() => {
      loadVideos();
    }, []),
  );

  const regularVideos = videos.filter((_, i) => i % 5 !== 2);
  const shortsVideos = videos.filter((_, i) => i % 5 === 2);

  const renderItem = ({ item, index }) => {
    // Insert Shorts section after first 2 videos
    if (index === 2 && shortsVideos.length > 0) {
      return (
        <>
          <View style={styles.sectionHeader}>
            <View style={styles.shortsIcon}>
              <Svg width="16" height="16" viewBox="0 0 24 24">
                <Path d="M17.77 10.32l-1.2-.5L18 9l.5-1.2.5 1.2 1.2.5-1.2.5L18.5 11l-.73-0.68z" fill="#FF0000" />
              </Svg>
            </View>
            <Text style={styles.sectionTitle}>Shorts</Text>
            <TouchableOpacity>
              <Text style={styles.moreDots}>⋮</Text>
            </TouchableOpacity>
          </View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.shortsRow}>
            {shortsVideos.slice(0, 6).map(v => (
              <ShortsCard
                key={v.id}
                video={v}
                onPress={() => navigation.navigate('VideoPlayer', { video: v, videos: shortsVideos })}
              />
            ))}
          </ScrollView>
          <VideoThumbnail
            video={item}
            onPress={() => navigation.navigate('VideoPlayer', { video: item, videos })}
          />
        </>
      );
    }

    return (
      <VideoThumbnail
        video={item}
        onPress={() => navigation.navigate('VideoPlayer', { video: item, videos })}
      />
    );
  };

  return (
    <View style={styles.container}>
      {/* Top Header */}
      <View style={styles.header}>
        <YTLogo />
        <View style={styles.headerIcons}>
          <TouchableOpacity style={styles.headerBtn}>
            <CastIcon />
          </TouchableOpacity>
          <TouchableOpacity style={styles.headerBtn}>
            <BellIcon />
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.headerBtn}
            onPress={() => navigation.navigate('Search')}>
            <SearchIcon />
          </TouchableOpacity>
        </View>
      </View>

      {/* Category Filter */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.categoryScroll}
        contentContainerStyle={styles.categoryContent}>
        <TouchableOpacity style={styles.categoryIconBtn}>
          <Svg width="18" height="18" viewBox="0 0 24 24" fill="#FFFFFF">
            <Circle cx="12" cy="12" r="10" fill="none" stroke="#FFFFFF" strokeWidth="2" />
            <Path d="M12 8v4l3 3" stroke="#FFFFFF" strokeWidth="2" />
          </Svg>
        </TouchableOpacity>
        {CATEGORIES.map(cat => (
          <TouchableOpacity
            key={cat}
            style={[
              styles.categoryBtn,
              selectedCategory === cat && styles.categoryBtnActive,
            ]}
            onPress={() => setSelectedCategory(cat)}>
            <Text
              style={[
                styles.categoryText,
                selectedCategory === cat && styles.categoryTextActive,
              ]}>
              {cat}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Video List */}
      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#FF0000" />
          <Text style={styles.loadingText}>Loading videos...</Text>
        </View>
      ) : videos.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Svg width="80" height="56" viewBox="0 0 90 63">
            <Rect x="0" y="0" width="90" height="63" rx="14" fill="#333" />
            <Path d="M 36 16 L 36 47 L 62 31.5 Z" fill="#555" />
          </Svg>
          <Text style={styles.emptyTitle}>No Videos Found</Text>
          <Text style={styles.emptySubtitle}>
            Add videos to your device storage{'\n'}(Movies, Videos, DCIM folders)
          </Text>
        </View>
      ) : (
        <FlatList
          data={regularVideos}
          keyExtractor={item => item.id}
          renderItem={renderItem}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={() => {
                setRefreshing(true);
                loadVideos(true);
              }}
              tintColor="#FF0000"
              colors={['#FF0000']}
            />
          }
          contentContainerStyle={{ paddingBottom: 80 }}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0F0F0F',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 12,
    paddingVertical: 10,
    backgroundColor: '#0F0F0F',
  },
  logoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  logoText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '700',
    letterSpacing: -0.5,
  },
  headerIcons: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  headerBtn: {
    padding: 8,
  },
  categoryScroll: {
    maxHeight: 44,
    backgroundColor: '#0F0F0F',
  },
  categoryContent: {
    paddingHorizontal: 8,
    alignItems: 'center',
    gap: 8,
  },
  categoryIconBtn: {
    width: 36,
    height: 32,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#272727',
    borderRadius: 8,
  },
  categoryBtn: {
    paddingHorizontal: 12,
    height: 32,
    justifyContent: 'center',
    backgroundColor: '#272727',
    borderRadius: 8,
  },
  categoryBtnActive: {
    backgroundColor: '#FFFFFF',
  },
  categoryText: {
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: '500',
  },
  categoryTextActive: {
    color: '#0F0F0F',
    fontWeight: '600',
  },
  videoCard: {
    marginBottom: 12,
  },
  thumbnailContainer: {
    position: 'relative',
    width: '100%',
    aspectRatio: 16 / 9,
    backgroundColor: '#1A1A1A',
  },
  thumbnail: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  thumbPlaceholder: {
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#1A1A1A',
  },
  durationBadge: {
    position: 'absolute',
    bottom: 6,
    right: 6,
    backgroundColor: 'rgba(0,0,0,0.8)',
    paddingHorizontal: 4,
    paddingVertical: 2,
    borderRadius: 3,
  },
  durationText: {
    color: '#FFFFFF',
    fontSize: 11,
    fontWeight: '600',
  },
  videoInfo: {
    flexDirection: 'row',
    paddingHorizontal: 12,
    paddingVertical: 10,
    gap: 10,
  },
  channelAvatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#FF0000',
    justifyContent: 'center',
    alignItems: 'center',
    flexShrink: 0,
  },
  avatarLetter: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
  videoMeta: {
    flex: 1,
  },
  videoTitle: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '400',
    lineHeight: 19,
    marginBottom: 3,
  },
  videoSubtitle: {
    color: '#AAAAAA',
    fontSize: 12,
    lineHeight: 16,
  },
  moreBtn: {
    padding: 4,
    paddingTop: 0,
  },
  moreDots: {
    color: '#AAAAAA',
    fontSize: 20,
    fontWeight: '600',
  },
  // Shorts
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 10,
    gap: 10,
  },
  shortsIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#FF0000',
    justifyContent: 'center',
    alignItems: 'center',
  },
  sectionTitle: {
    flex: 1,
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  shortsRow: {
    paddingHorizontal: 8,
    marginBottom: 12,
  },
  shortsCard: {
    width: 160,
    marginHorizontal: 4,
  },
  shortsThumb: {
    width: 160,
    height: 284,
    borderRadius: 10,
    backgroundColor: '#1A1A1A',
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
  },
  shortsThumbImg: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
    position: 'absolute',
  },
  shortsThumbFallback: {
    position: 'absolute',
  },
  shortsTitle: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '500',
    marginTop: 6,
    paddingHorizontal: 4,
    lineHeight: 16,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: '#AAAAAA',
    fontSize: 14,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
    padding: 40,
  },
  emptyTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '600',
  },
  emptySubtitle: {
    color: '#AAAAAA',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },
});
