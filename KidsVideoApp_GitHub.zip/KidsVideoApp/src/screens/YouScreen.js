// YouScreen.js
import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, ScrollView,
  FlatList, Image,
} from 'react-native';
import Svg, { Path, Rect, Circle } from 'react-native-svg';
import { useFocusEffect } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function YouScreen({ navigation }) {
  const [recentVideos, setRecentVideos] = useState([]);
  const [totalVideos, setTotalVideos] = useState(0);

  useFocusEffect(
    useCallback(() => {
      loadData();
    }, []),
  );

  const loadData = async () => {
    try {
      const cached = await AsyncStorage.getItem('video_cache');
      if (cached) {
        const vids = JSON.parse(cached);
        setTotalVideos(vids.length);
        setRecentVideos(vids.slice(0, 3));
      }
    } catch (e) {}
  };

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Top icons */}
      <View style={styles.topBar}>
        <View style={{ flex: 1 }} />
        <TouchableOpacity style={styles.topBtn}>
          <Svg width="24" height="24" viewBox="0 0 24 24" fill="#FFF">
            <Path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z" />
          </Svg>
        </TouchableOpacity>
        <TouchableOpacity style={styles.topBtn}>
          <Svg width="24" height="24" viewBox="0 0 24 24" fill="#FFF">
            <Path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.9 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z" />
          </Svg>
        </TouchableOpacity>
        <TouchableOpacity style={styles.topBtn}>
          <Svg width="24" height="24" viewBox="0 0 24 24" fill="#FFF">
            <Path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z" />
          </Svg>
        </TouchableOpacity>
      </View>

      {/* Profile */}
      <View style={styles.profileSection}>
        <View style={styles.bigAvatar}>
          <Text style={styles.bigAvatarTxt}>K</Text>
        </View>
        <Text style={styles.profileName}>Kids Video</Text>
        <Text style={styles.profileHandle}>@kidsvideo · View channel</Text>

        <View style={styles.profileActions}>
          <TouchableOpacity style={styles.profileActionBtn}>
            <Svg width="18" height="18" viewBox="0 0 24 24" fill="#FFF">
              <Path d="M10 9H5L3 7l2-2h5V3l4 4-4 4V9zm4 6h5l2 2-2 2h-5v2l-4-4 4-4v2z" />
            </Svg>
            <Text style={styles.profileActionTxt}>Switch account</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.profileActionBtn}>
            <Svg width="18" height="18" viewBox="0 0 24 24" fill="#FFF">
              <Path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-1-4h2v2h-2zm0-2h2V7h-2z" />
            </Svg>
            <Text style={styles.profileActionTxt}>Google Account</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.profileActionBtn}>
            <Svg width="18" height="18" viewBox="0 0 24 24" fill="#FFF">
              <Path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z" />
            </Svg>
            <Text style={styles.profileActionTxt}>Turn on Incognito</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Stats */}
      <View style={styles.statsRow}>
        <View style={styles.statItem}>
          <Text style={styles.statNum}>{totalVideos}</Text>
          <Text style={styles.statLabel}>Total Videos</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statItem}>
          <Text style={styles.statNum}>Local</Text>
          <Text style={styles.statLabel}>Source</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statItem}>
          <Text style={styles.statNum}>∞</Text>
          <Text style={styles.statLabel}>Offline</Text>
        </View>
      </View>

      {/* History */}
      {recentVideos.length > 0 && (
        <View style={styles.section}>
          <View style={styles.sectionHeaderRow}>
            <Text style={styles.sectionTitle}>History</Text>
            <TouchableOpacity>
              <Svg width="16" height="16" viewBox="0 0 24 24" fill="#FFF">
                <Path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z" />
              </Svg>
            </TouchableOpacity>
          </View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View style={{ flexDirection: 'row', gap: 8, paddingLeft: 2 }}>
              {recentVideos.map(v => (
                <TouchableOpacity
                  key={v.id}
                  style={styles.historyCard}
                  onPress={() => navigation.navigate('VideoPlayer', { video: v, videos: recentVideos })}>
                  <View style={styles.historyThumb}>
                    <Image source={{ uri: v.uri }} style={styles.historyThumbImg} onError={() => {}} />
                    <View style={styles.historyThumbFallback}>
                      <Svg width="28" height="20" viewBox="0 0 90 63">
                        <Rect x="0" y="0" width="90" height="63" rx="8" fill="#333" />
                        <Path d="M 36 16 L 36 47 L 62 31.5 Z" fill="#555" />
                      </Svg>
                    </View>
                  </View>
                  <Text style={styles.historyTitle} numberOfLines={2}>{v.title}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>
        </View>
      )}

      {/* Playlists */}
      <View style={styles.section}>
        <View style={styles.sectionHeaderRow}>
          <Text style={styles.sectionTitle}>Playlists</Text>
          <TouchableOpacity>
            <Text style={styles.addIcon}>+</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.playlistRow}>
          <View style={styles.playlistCard}>
            <View style={styles.playlistThumb}>
              <Svg width="32" height="32" viewBox="0 0 24 24" fill="#555">
                <Path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67V7z" />
              </Svg>
            </View>
            <Text style={styles.playlistTitle}>Watch later</Text>
            <Text style={styles.playlistSub}>Private</Text>
          </View>
          <View style={styles.playlistCard}>
            <View style={styles.playlistThumb}>
              <Svg width="32" height="32" viewBox="0 0 24 24" fill="#555">
                <Path d="M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z" />
              </Svg>
            </View>
            <Text style={styles.playlistTitle}>Liked videos</Text>
            <Text style={styles.playlistSub}>Private</Text>
          </View>
        </View>
      </View>

      {/* Menu items */}
      {[
        { icon: 'M18 3v2h-2V3H8v2H6V3H4v18h2v-2h2v2h8v-2h2v2h2V3h-2zM8 17H6v-2h2v2zm0-4H6v-2h2v2zm0-4H6V7h2v2zm10 8h-2v-2h2v2zm0-4h-2v-2h2v2zm0-4h-2V7h2v2z', label: 'Your videos' },
        { icon: 'M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z', label: 'Downloads' },
        { icon: 'M18 4l2 4h-3l-2-4h-2l2 4h-3l-2-4H8l2 4H7L5 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V4h-4z', label: 'Movies' },
      ].map(item => (
        <TouchableOpacity key={item.label} style={styles.menuItem}>
          <Svg width="22" height="22" viewBox="0 0 24 24" fill="#FFFFFF">
            <Path d={item.icon} />
          </Svg>
          <Text style={styles.menuLabel}>{item.label}</Text>
          <Svg width="16" height="16" viewBox="0 0 24 24" fill="#666">
            <Path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z" />
          </Svg>
        </TouchableOpacity>
      ))}

      <View style={{ height: 80 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0F0F0F' },
  topBar: {
    flexDirection: 'row',
    paddingHorizontal: 8,
    paddingVertical: 8,
    gap: 4,
  },
  topBtn: { padding: 8 },
  profileSection: { alignItems: 'center', paddingVertical: 20, paddingHorizontal: 16, gap: 8 },
  bigAvatar: {
    width: 72, height: 72, borderRadius: 36,
    backgroundColor: '#FF0000',
    justifyContent: 'center', alignItems: 'center',
  },
  bigAvatarTxt: { color: '#FFF', fontSize: 32, fontWeight: '700' },
  profileName: { color: '#FFF', fontSize: 20, fontWeight: '700' },
  profileHandle: { color: '#AAA', fontSize: 13 },
  profileActions: { flexDirection: 'row', gap: 8, marginTop: 8, flexWrap: 'wrap', justifyContent: 'center' },
  profileActionBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: '#272727',
    paddingHorizontal: 12, paddingVertical: 8,
    borderRadius: 20,
  },
  profileActionTxt: { color: '#FFF', fontSize: 13 },
  statsRow: {
    flexDirection: 'row',
    backgroundColor: '#1A1A1A',
    marginHorizontal: 12,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  statItem: { flex: 1, alignItems: 'center', gap: 4 },
  statNum: { color: '#FFF', fontSize: 18, fontWeight: '700' },
  statLabel: { color: '#AAA', fontSize: 11 },
  statDivider: { width: 1, backgroundColor: '#333', marginVertical: 4 },
  section: { paddingHorizontal: 12, marginBottom: 20 },
  sectionHeaderRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  sectionTitle: { color: '#FFF', fontSize: 16, fontWeight: '600' },
  addIcon: { color: '#FFF', fontSize: 22, fontWeight: '300' },
  historyCard: { width: 160 },
  historyThumb: { width: 160, height: 90, borderRadius: 8, backgroundColor: '#1A1A1A', overflow: 'hidden', justifyContent: 'center', alignItems: 'center' },
  historyThumbImg: { ...StyleSheet.absoluteFillObject, resizeMode: 'cover' },
  historyThumbFallback: { justifyContent: 'center', alignItems: 'center' },
  historyTitle: { color: '#FFF', fontSize: 12, marginTop: 6, lineHeight: 16 },
  playlistRow: { flexDirection: 'row', gap: 12 },
  playlistCard: { flex: 1, gap: 6 },
  playlistThumb: { height: 100, borderRadius: 8, backgroundColor: '#1A1A1A', justifyContent: 'center', alignItems: 'center' },
  playlistTitle: { color: '#FFF', fontSize: 13, fontWeight: '500' },
  playlistSub: { color: '#AAA', fontSize: 11 },
  menuItem: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 16, paddingVertical: 14,
    borderTopWidth: 0.5, borderTopColor: '#1A1A1A',
    gap: 16,
  },
  menuLabel: { flex: 1, color: '#FFF', fontSize: 15 },
});
