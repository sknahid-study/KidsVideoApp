// SubscriptionsScreen.js
import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, FlatList,
  TouchableOpacity, Image,
} from 'react-native';
import Svg, { Path, Rect } from 'react-native-svg';
import { useFocusEffect } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getVideosByFolder } from '../utils/VideoUtils';

export default function SubscriptionsScreen({ navigation }) {
  const [folders, setFolders] = useState({});
  const [selectedFolder, setSelectedFolder] = useState('All');
  const [allVideos, setAllVideos] = useState([]);

  useFocusEffect(
    useCallback(() => {
      loadData();
    }, []),
  );

  const loadData = async () => {
    try {
      const cached = await AsyncStorage.getItem('video_cache');
      if (cached) {
        const vids = JSON.parse(cached);
        setAllVideos(vids);
        setFolders(getVideosByFolder(vids));
      }
    } catch (e) {}
  };

  const folderNames = Object.keys(folders);
  const displayVideos = selectedFolder === 'All'
    ? allVideos
    : folders[selectedFolder] || [];

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Subscriptions</Text>
        <View style={styles.headerIcons}>
          <TouchableOpacity style={styles.iconBtn}>
            <Svg width="24" height="24" viewBox="0 0 24 24" fill="#FFF">
              <Path d="M21 3H3c-1.1 0-2 .9-2 2v3h2V5h18v14h-7v2h7c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z" />
            </Svg>
          </TouchableOpacity>
          <TouchableOpacity style={styles.iconBtn}>
            <Svg width="24" height="24" viewBox="0 0 24 24" fill="#FFF">
              <Path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z" />
            </Svg>
          </TouchableOpacity>
        </View>
      </View>

      {/* Folder/Channel row */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.folderRow}
        contentContainerStyle={styles.folderContent}>
        {/* All */}
        <TouchableOpacity
          style={[styles.folderItem, selectedFolder === 'All' && styles.folderItemActive]}
          onPress={() => setSelectedFolder('All')}>
          <View style={[styles.folderAvatar, { backgroundColor: '#FF0000' }]}>
            <Text style={styles.folderAvatarTxt}>A</Text>
          </View>
          <Text style={styles.folderName}>All</Text>
          {selectedFolder === 'All' && <View style={styles.folderDot} />}
        </TouchableOpacity>

        {folderNames.map(name => (
          <TouchableOpacity
            key={name}
            style={[styles.folderItem, selectedFolder === name && styles.folderItemActive]}
            onPress={() => setSelectedFolder(name)}>
            <View style={[styles.folderAvatar, { backgroundColor: getColor(name) }]}>
              <Text style={styles.folderAvatarTxt}>{name[0]?.toUpperCase()}</Text>
            </View>
            <Text style={styles.folderName} numberOfLines={1}>{name}</Text>
            {selectedFolder === name && <View style={styles.folderDot} />}
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Filter tabs */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filterScroll}>
        <View style={styles.filterRow}>
          {['All', 'Today', 'Videos', 'Shorts', 'Live', 'Posts'].map(f => (
            <TouchableOpacity key={f} style={[styles.filterChip, f === 'All' && styles.filterChipActive]}>
              <Text style={[styles.filterTxt, f === 'All' && styles.filterTxtActive]}>{f}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      {/* Video grid */}
      <FlatList
        data={displayVideos}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.videoCard}
            onPress={() => navigation.navigate('VideoPlayer', { video: item, videos: displayVideos })}
            activeOpacity={0.8}>
            <View style={styles.thumb}>
              <Image source={{ uri: item.uri }} style={styles.thumbImg} onError={() => {}} />
              <View style={styles.thumbFallback}>
                <Svg width="40" height="28" viewBox="0 0 90 63">
                  <Rect x="0" y="0" width="90" height="63" rx="8" fill="#333" />
                  <Path d="M 36 16 L 36 47 L 62 31.5 Z" fill="#555" />
                </Svg>
              </View>
            </View>
            <View style={styles.cardInfo}>
              <View style={styles.smallAvatar}>
                <Text style={styles.smallAvatarTxt}>{item.folderName?.[0]?.toUpperCase()}</Text>
              </View>
              <View style={styles.cardMeta}>
                <Text style={styles.cardTitle} numberOfLines={2}>{item.title}</Text>
                <Text style={styles.cardSub}>{item.folderName} · {item.sizeFormatted}</Text>
              </View>
              <TouchableOpacity style={styles.moreBtn}>
                <Text style={styles.moreDots}>⋮</Text>
              </TouchableOpacity>
            </View>
          </TouchableOpacity>
        )}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 80 }}
      />
    </View>
  );
}

const COLORS = ['#FF4444', '#4444FF', '#44FF44', '#FF9900', '#9944FF', '#FF44AA'];
const getColor = name => COLORS[name.charCodeAt(0) % COLORS.length];

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0F0F0F' },
  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 12, paddingVertical: 10,
  },
  headerTitle: { flex: 1, color: '#FFF', fontSize: 20, fontWeight: '700' },
  headerIcons: { flexDirection: 'row' },
  iconBtn: { padding: 8 },
  folderRow: { maxHeight: 90 },
  folderContent: { paddingHorizontal: 8, gap: 16, alignItems: 'center' },
  folderItem: { alignItems: 'center', gap: 4, width: 64 },
  folderItemActive: {},
  folderAvatar: {
    width: 48, height: 48, borderRadius: 24,
    justifyContent: 'center', alignItems: 'center',
    borderWidth: 2, borderColor: 'transparent',
  },
  folderAvatarTxt: { color: '#FFF', fontSize: 20, fontWeight: '700' },
  folderName: { color: '#FFF', fontSize: 10, textAlign: 'center' },
  folderDot: { width: 4, height: 4, borderRadius: 2, backgroundColor: '#FF0000' },
  filterScroll: { borderBottomWidth: 0.5, borderBottomColor: '#272727' },
  filterRow: { flexDirection: 'row', paddingHorizontal: 10, paddingVertical: 8, gap: 8 },
  filterChip: {
    paddingHorizontal: 14, paddingVertical: 6,
    borderRadius: 16, backgroundColor: '#272727',
  },
  filterChipActive: { backgroundColor: '#FFF' },
  filterTxt: { color: '#FFF', fontSize: 13 },
  filterTxtActive: { color: '#0F0F0F', fontWeight: '600' },
  videoCard: { marginBottom: 12 },
  thumb: { width: '100%', aspectRatio: 16 / 9, backgroundColor: '#1A1A1A', justifyContent: 'center', alignItems: 'center' },
  thumbImg: { ...StyleSheet.absoluteFillObject, resizeMode: 'cover' },
  thumbFallback: { justifyContent: 'center', alignItems: 'center' },
  cardInfo: { flexDirection: 'row', paddingHorizontal: 12, paddingVertical: 8, gap: 10 },
  smallAvatar: { width: 36, height: 36, borderRadius: 18, backgroundColor: '#FF0000', justifyContent: 'center', alignItems: 'center' },
  smallAvatarTxt: { color: '#FFF', fontSize: 14, fontWeight: '700' },
  cardMeta: { flex: 1 },
  cardTitle: { color: '#FFF', fontSize: 14, lineHeight: 19, marginBottom: 3 },
  cardSub: { color: '#AAA', fontSize: 12 },
  moreBtn: { padding: 4 },
  moreDots: { color: '#AAA', fontSize: 20 },
});
