import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  FlatList,
  Image,
} from 'react-native';
import Svg, { Path, Rect } from 'react-native-svg';
import { searchVideos, formatDuration } from '../utils/VideoUtils';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function SearchScreen({ navigation }) {
  const [query, setQuery] = useState('');
  const [allVideos, setAllVideos] = useState([]);
  const [results, setResults] = useState([]);
  const inputRef = React.useRef(null);

  useEffect(() => {
    inputRef.current?.focus();
    loadVideos();
  }, []);

  const loadVideos = async () => {
    try {
      const cached = await AsyncStorage.getItem('video_cache');
      if (cached) setAllVideos(JSON.parse(cached));
    } catch (e) {}
  };

  useEffect(() => {
    if (query.trim()) {
      setResults(searchVideos(allVideos, query));
    } else {
      setResults([]);
    }
  }, [query, allVideos]);

  return (
    <View style={styles.container}>
      {/* Search Bar */}
      <View style={styles.searchBar}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Svg width="24" height="24" viewBox="0 0 24 24" fill="#FFFFFF">
            <Path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z" />
          </Svg>
        </TouchableOpacity>
        <TextInput
          ref={inputRef}
          style={styles.searchInput}
          value={query}
          onChangeText={setQuery}
          placeholder="Search videos..."
          placeholderTextColor="#666"
          returnKeyType="search"
          clearButtonMode="while-editing"
          autoCorrect={false}
          autoCapitalize="none"
        />
        {query.length > 0 && (
          <TouchableOpacity onPress={() => setQuery('')} style={styles.clearBtn}>
            <Svg width="20" height="20" viewBox="0 0 24 24" fill="#AAAAAA">
              <Path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z" />
            </Svg>
          </TouchableOpacity>
        )}
      </View>

      {query.trim() === '' ? (
        <View style={styles.hintContainer}>
          <Svg width="64" height="64" viewBox="0 0 24 24" fill="#333">
            <Path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z" />
          </Svg>
          <Text style={styles.hintText}>Search your videos</Text>
          <Text style={styles.hintSub}>Search by title, filename, or folder name</Text>
        </View>
      ) : results.length === 0 ? (
        <View style={styles.hintContainer}>
          <Text style={styles.noResults}>No videos found for "{query}"</Text>
        </View>
      ) : (
        <FlatList
          data={results}
          keyExtractor={item => item.id}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={styles.resultItem}
              onPress={() => navigation.navigate('VideoPlayer', { video: item, videos: results })}
              activeOpacity={0.8}>
              <View style={styles.resultThumb}>
                <Image
                  source={{ uri: item.uri }}
                  style={styles.resultThumbImg}
                  onError={() => {}}
                />
                <View style={styles.fallbackThumb}>
                  <Svg width="36" height="26" viewBox="0 0 90 63">
                    <Rect x="0" y="0" width="90" height="63" rx="8" fill="#333" />
                    <Path d="M 36 16 L 36 47 L 62 31.5 Z" fill="#555" />
                  </Svg>
                </View>
              </View>
              <View style={styles.resultInfo}>
                <Text style={styles.resultTitle} numberOfLines={2}>{item.title}</Text>
                <Text style={styles.resultMeta}>{item.folderName} · {item.sizeFormatted}</Text>
                <Text style={styles.resultMeta}>{item.timeAgo}</Text>
              </View>
              <TouchableOpacity style={styles.resultMore}>
                <Text style={styles.moreDots}>⋮</Text>
              </TouchableOpacity>
            </TouchableOpacity>
          )}
          contentContainerStyle={{ paddingBottom: 60 }}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0F0F0F' },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 8,
    borderBottomWidth: 0.5,
    borderBottomColor: '#272727',
    gap: 8,
  },
  backBtn: { padding: 6 },
  searchInput: {
    flex: 1,
    height: 40,
    color: '#FFFFFF',
    fontSize: 16,
    backgroundColor: '#1A1A1A',
    borderRadius: 20,
    paddingHorizontal: 16,
  },
  clearBtn: { padding: 6 },
  hintContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12 },
  hintText: { color: '#FFFFFF', fontSize: 16, fontWeight: '600' },
  hintSub: { color: '#AAAAAA', fontSize: 13, textAlign: 'center' },
  noResults: { color: '#AAAAAA', fontSize: 15 },
  resultItem: {
    flexDirection: 'row',
    paddingHorizontal: 12,
    paddingVertical: 10,
    gap: 10,
    alignItems: 'center',
  },
  resultThumb: {
    width: 120,
    height: 68,
    borderRadius: 6,
    backgroundColor: '#1A1A1A',
    overflow: 'hidden',
    flexShrink: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
  resultThumbImg: { ...StyleSheet.absoluteFillObject, resizeMode: 'cover' },
  fallbackThumb: { justifyContent: 'center', alignItems: 'center' },
  resultInfo: { flex: 1 },
  resultTitle: { color: '#FFFFFF', fontSize: 13, fontWeight: '500', lineHeight: 18, marginBottom: 4 },
  resultMeta: { color: '#AAAAAA', fontSize: 11, lineHeight: 16 },
  resultMore: { padding: 6 },
  moreDots: { color: '#AAAAAA', fontSize: 20 },
});
