import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  ActivityIndicator, Alert,
} from 'react-native';
import RNFS from 'react-native-fs';
import Svg, { Path, Rect } from 'react-native-svg';
import { requestStoragePermission, isVideoFile, formatFileSize } from '../utils/VideoUtils';

export default function FolderBrowserScreen({ navigation }) {
  const [currentPath, setCurrentPath] = useState(RNFS.ExternalStorageDirectoryPath || RNFS.DocumentDirectoryPath);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [pathHistory, setPathHistory] = useState([]);

  useEffect(() => {
    requestStoragePermission().then(granted => {
      if (granted) loadDirectory(currentPath);
      else Alert.alert('Permission needed', 'Storage permission required');
    });
  }, []);

  const loadDirectory = async (path) => {
    setLoading(true);
    try {
      const dirItems = await RNFS.readDir(path);
      const filtered = dirItems
        .filter(item => !item.name.startsWith('.'))
        .filter(item => item.isDirectory() || isVideoFile(item.name))
        .sort((a, b) => {
          if (a.isDirectory() && !b.isDirectory()) return -1;
          if (!a.isDirectory() && b.isDirectory()) return 1;
          return a.name.localeCompare(b.name);
        });
      setItems(filtered);
      setCurrentPath(path);
    } catch (e) {
      Alert.alert('Error', 'Cannot access this folder');
    }
    setLoading(false);
  };

  const navigateTo = (path) => {
    setPathHistory(h => [...h, currentPath]);
    loadDirectory(path);
  };

  const goBack = () => {
    if (pathHistory.length > 0) {
      const prev = pathHistory[pathHistory.length - 1];
      setPathHistory(h => h.slice(0, -1));
      loadDirectory(prev);
    } else {
      navigation.goBack();
    }
  };

  const folderName = currentPath.split('/').pop() || 'Storage';

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={goBack} style={styles.backBtn}>
          <Svg width="24" height="24" viewBox="0 0 24 24" fill="#FFF">
            <Path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z" />
          </Svg>
        </TouchableOpacity>
        <Text style={styles.headerTitle} numberOfLines={1}>{folderName}</Text>
      </View>

      {/* Breadcrumb */}
      <Text style={styles.breadcrumb} numberOfLines={1}>
        📁 {currentPath}
      </Text>

      {loading ? (
        <View style={styles.loading}>
          <ActivityIndicator size="large" color="#FF0000" />
        </View>
      ) : (
        <FlatList
          data={items}
          keyExtractor={item => item.path}
          renderItem={({ item }) => {
            const isDir = item.isDirectory();
            const isVideo = !isDir && isVideoFile(item.name);

            return (
              <TouchableOpacity
                style={styles.item}
                onPress={() => {
                  if (isDir) {
                    navigateTo(item.path);
                  } else if (isVideo) {
                    const videoObj = {
                      id: item.path,
                      path: item.path,
                      uri: `file://${item.path}`,
                      name: item.name,
                      title: item.name.replace(/\.[^/.]+$/, '').replace(/[_.\-]+/g, ' '),
                      size: parseInt(item.size, 10),
                      sizeFormatted: formatFileSize(parseInt(item.size, 10)),
                      mtime: item.mtime,
                      timeAgo: '',
                      folder: currentPath,
                      folderName: folderName,
                      duration: 0,
                      thumbnail: null,
                    };
                    navigation.navigate('VideoPlayer', { video: videoObj, videos: [] });
                  }
                }}
                activeOpacity={0.7}>
                <View style={styles.itemIcon}>
                  {isDir ? (
                    <Svg width="28" height="28" viewBox="0 0 24 24" fill="#FFCC02">
                      <Path d="M10 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z" />
                    </Svg>
                  ) : (
                    <Svg width="28" height="28" viewBox="0 0 24 24" fill="#FF0000">
                      <Rect x="2" y="4" width="20" height="16" rx="2" fill="#FF0000" opacity="0.9" />
                      <Path d="M10 8.5v7l5-3.5-5-3.5z" fill="#FFF" />
                    </Svg>
                  )}
                </View>
                <View style={styles.itemInfo}>
                  <Text style={styles.itemName} numberOfLines={1}>{item.name}</Text>
                  {!isDir && (
                    <Text style={styles.itemSize}>{formatFileSize(parseInt(item.size, 10))}</Text>
                  )}
                  {isDir && (
                    <Text style={styles.itemSize}>Folder</Text>
                  )}
                </View>
                {isDir && (
                  <Svg width="20" height="20" viewBox="0 0 24 24" fill="#666">
                    <Path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z" />
                  </Svg>
                )}
              </TouchableOpacity>
            );
          }}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Text style={styles.emptyText}>This folder is empty</Text>
            </View>
          }
          contentContainerStyle={{ paddingBottom: 60 }}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0F0F0F' },
  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 8, paddingVertical: 10,
    borderBottomWidth: 0.5, borderBottomColor: '#272727',
    gap: 8,
  },
  backBtn: { padding: 6 },
  headerTitle: { flex: 1, color: '#FFF', fontSize: 18, fontWeight: '700' },
  breadcrumb: {
    color: '#666', fontSize: 11,
    paddingHorizontal: 16, paddingVertical: 6,
    backgroundColor: '#1A1A1A',
  },
  loading: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  item: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 16, paddingVertical: 12,
    borderBottomWidth: 0.5, borderBottomColor: '#1A1A1A',
    gap: 12,
  },
  itemIcon: { width: 36, alignItems: 'center' },
  itemInfo: { flex: 1 },
  itemName: { color: '#FFF', fontSize: 14 },
  itemSize: { color: '#666', fontSize: 12, marginTop: 2 },
  empty: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 40 },
  emptyText: { color: '#666', fontSize: 14 },
});
