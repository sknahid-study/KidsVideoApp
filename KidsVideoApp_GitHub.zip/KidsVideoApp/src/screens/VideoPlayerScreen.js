import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  Dimensions,
  StatusBar,
  Animated,
  PanResponder,
  ScrollView,
  Image,
  BackHandler,
} from 'react-native';
import Video from 'react-native-video';
import Orientation from 'react-native-orientation-locker';
import Svg, { Path, Rect, Circle } from 'react-native-svg';
import { formatDuration } from '../utils/VideoUtils';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');
const MINI_HEIGHT = 80;
const PLAYER_HEIGHT = SCREEN_WIDTH * (9 / 16);

// Icons
const PlayIcon = ({ size = 36, color = '#FFF' }) => (
  <Svg width={size} height={size} viewBox="0 0 24 24" fill={color}>
    <Path d="M8 5v14l11-7z" />
  </Svg>
);

const PauseIcon = ({ size = 36, color = '#FFF' }) => (
  <Svg width={size} height={size} viewBox="0 0 24 24" fill={color}>
    <Path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z" />
  </Svg>
);

const FullscreenIcon = ({ size = 20 }) => (
  <Svg width={size} height={size} viewBox="0 0 24 24" fill="#FFF">
    <Path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z" />
  </Svg>
);

const ExitFullscreenIcon = ({ size = 20 }) => (
  <Svg width={size} height={size} viewBox="0 0 24 24" fill="#FFF">
    <Path d="M5 16h3v3h2v-5H5v2zm3-8H5v2h5V5H8v3zm6 11h2v-3h3v-2h-5v5zm2-11V5h-2v5h5V8h-3z" />
  </Svg>
);

const ReplayIcon = () => (
  <Svg width="44" height="44" viewBox="0 0 24 24" fill="#FFF">
    <Path d="M12 5V1L7 6l5 5V7c3.31 0 6 2.69 6 6s-2.69 6-6 6-6-2.69-6-6H4c0 4.42 3.58 8 8 8s8-3.58 8-8-3.58-8-8-8z" />
  </Svg>
);

const BackwardIcon = () => (
  <Svg width="32" height="32" viewBox="0 0 24 24" fill="#FFF">
    <Path d="M11 18V6l-8.5 6 8.5 6zm.5-6l8.5 6V6l-8.5 6z" />
  </Svg>
);

const ForwardIcon = () => (
  <Svg width="32" height="32" viewBox="0 0 24 24" fill="#FFF">
    <Path d="M4 18l8.5-6L4 6v12zm9-12v12l8.5-6L13 6z" />
  </Svg>
);

const ProgressBar = ({ progress, buffered, duration, onSeek }) => {
  const barRef = useRef(null);
  const [barWidth, setBarWidth] = useState(1);

  const handlePress = e => {
    const x = e.nativeEvent.locationX;
    const ratio = Math.max(0, Math.min(1, x / barWidth));
    onSeek(ratio * duration);
  };

  return (
    <TouchableOpacity
      activeOpacity={1}
      onPress={handlePress}
      onLayout={e => setBarWidth(e.nativeEvent.layout.width)}>
      <View style={styles.progressTrack}>
        {/* Buffered */}
        <View style={[styles.progressBuffered, { width: `${buffered * 100}%` }]} />
        {/* Played */}
        <View style={[styles.progressPlayed, { width: `${progress * 100}%` }]} />
        {/* Thumb */}
        <View style={[styles.progressThumb, { left: `${progress * 100}%` }]} />
      </View>
    </TouchableOpacity>
  );
};

export default function VideoPlayerScreen({ route, navigation }) {
  const { video, videos = [] } = route.params;
  const videoRef = useRef(null);

  const [currentVideo, setCurrentVideo] = useState(video);
  const [paused, setPaused] = useState(false);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [buffered, setBuffered] = useState(0);
  const [showControls, setShowControls] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [ended, setEnded] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [expanded, setExpanded] = useState(true);
  const [showDescription, setShowDescription] = useState(false);

  const controlsTimer = useRef(null);
  const controlsOpacity = useRef(new Animated.Value(1)).current;

  const relatedVideos = videos.filter(v => v.id !== currentVideo.id);

  useEffect(() => {
    const backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      if (isFullscreen) {
        exitFullscreen();
        return true;
      }
      navigation.goBack();
      return true;
    });
    return () => backHandler.remove();
  }, [isFullscreen]);

  useEffect(() => {
    if (showControls) {
      scheduleHideControls();
    }
  }, [showControls, paused]);

  const scheduleHideControls = () => {
    if (controlsTimer.current) clearTimeout(controlsTimer.current);
    if (!paused) {
      controlsTimer.current = setTimeout(() => {
        Animated.timing(controlsOpacity, {
          toValue: 0,
          duration: 300,
          useNativeDriver: true,
        }).start(() => setShowControls(false));
      }, 3000);
    }
  };

  const toggleControls = () => {
    if (showControls) {
      Animated.timing(controlsOpacity, {
        toValue: 0,
        duration: 200,
        useNativeDriver: true,
      }).start(() => setShowControls(false));
    } else {
      setShowControls(true);
      Animated.timing(controlsOpacity, {
        toValue: 1,
        duration: 200,
        useNativeDriver: true,
      }).start();
      scheduleHideControls();
    }
  };

  const enterFullscreen = () => {
    setIsFullscreen(true);
    StatusBar.setHidden(true);
    Orientation.lockToLandscape();
  };

  const exitFullscreen = () => {
    setIsFullscreen(false);
    StatusBar.setHidden(false);
    Orientation.lockToPortrait();
  };

  const seekBy = seconds => {
    const newTime = Math.max(0, Math.min(duration, currentTime + seconds));
    videoRef.current?.seek(newTime);
    setCurrentTime(newTime);
  };

  const playerHeight = isFullscreen ? SCREEN_HEIGHT : PLAYER_HEIGHT;
  const playerWidth = isFullscreen ? SCREEN_HEIGHT * (16 / 9) : SCREEN_WIDTH;

  return (
    <View style={[styles.container, isFullscreen && styles.fullscreenContainer]}>
      <StatusBar hidden={isFullscreen} barStyle="light-content" backgroundColor="#000" />

      {/* Video Player Area */}
      <View
        style={[
          styles.playerWrapper,
          isFullscreen && styles.playerFullscreen,
          { height: playerHeight },
        ]}>
        <TouchableOpacity
          activeOpacity={1}
          style={StyleSheet.absoluteFill}
          onPress={toggleControls}>
          <Video
            ref={videoRef}
            source={{ uri: currentVideo.uri }}
            style={StyleSheet.absoluteFill}
            resizeMode={isFullscreen ? 'contain' : 'contain'}
            paused={paused}
            onLoad={data => {
              setDuration(data.duration);
              setIsLoading(false);
              setEnded(false);
            }}
            onProgress={data => {
              setCurrentTime(data.currentTime);
              if (data.playableDuration > 0) {
                setBuffered(data.playableDuration / duration);
              }
            }}
            onEnd={() => {
              setEnded(true);
              setPaused(true);
              setShowControls(true);
              Animated.timing(controlsOpacity, { toValue: 1, duration: 200, useNativeDriver: true }).start();
            }}
            onLoadStart={() => setIsLoading(true)}
            onReadyForDisplay={() => setIsLoading(false)}
            ignoreSilentSwitch="ignore"
            playInBackground={false}
            playWhenInactive={false}
            progressUpdateInterval={500}
          />

          {/* Controls Overlay */}
          {showControls && (
            <Animated.View style={[styles.controlsOverlay, { opacity: controlsOpacity }]}>
              {/* Top bar */}
              <View style={styles.topBar}>
                {isFullscreen ? (
                  <TouchableOpacity onPress={exitFullscreen} style={styles.backBtn}>
                    <Svg width="24" height="24" viewBox="0 0 24 24" fill="#FFF">
                      <Path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z" />
                    </Svg>
                  </TouchableOpacity>
                ) : (
                  <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
                    <Svg width="24" height="24" viewBox="0 0 24 24" fill="#FFF">
                      <Path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z" />
                    </Svg>
                  </TouchableOpacity>
                )}
                <Text style={styles.playerTitle} numberOfLines={1}>{currentVideo.title}</Text>
                <View style={styles.topBarRight}>
                  <TouchableOpacity style={styles.iconBtn}>
                    <Svg width="20" height="20" viewBox="0 0 24 24" fill="#FFF">
                      <Circle cx="5" cy="12" r="2" />
                      <Circle cx="12" cy="12" r="2" />
                      <Circle cx="19" cy="12" r="2" />
                    </Svg>
                  </TouchableOpacity>
                </View>
              </View>

              {/* Center controls */}
              <View style={styles.centerControls}>
                <TouchableOpacity onPress={() => seekBy(-10)}>
                  <BackwardIcon />
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.playPauseBtn}
                  onPress={() => {
                    if (ended) {
                      videoRef.current?.seek(0);
                      setEnded(false);
                      setPaused(false);
                    } else {
                      setPaused(p => !p);
                    }
                  }}>
                  {ended ? (
                    <ReplayIcon />
                  ) : paused ? (
                    <PlayIcon size={44} />
                  ) : (
                    <PauseIcon size={44} />
                  )}
                </TouchableOpacity>

                <TouchableOpacity onPress={() => seekBy(10)}>
                  <ForwardIcon />
                </TouchableOpacity>
              </View>

              {/* Bottom controls */}
              <View style={styles.bottomControls}>
                <ProgressBar
                  progress={duration > 0 ? currentTime / duration : 0}
                  buffered={buffered}
                  duration={duration}
                  onSeek={time => {
                    videoRef.current?.seek(time);
                    setCurrentTime(time);
                  }}
                />
                <View style={styles.timeRow}>
                  <Text style={styles.timeText}>
                    {formatDuration(currentTime)} / {formatDuration(duration)}
                  </Text>
                  <TouchableOpacity
                    onPress={isFullscreen ? exitFullscreen : enterFullscreen}>
                    {isFullscreen ? <ExitFullscreenIcon /> : <FullscreenIcon />}
                  </TouchableOpacity>
                </View>
              </View>
            </Animated.View>
          )}

          {/* Loading indicator */}
          {isLoading && (
            <View style={styles.loadingOverlay}>
              <View style={styles.loadingSpinner} />
            </View>
          )}
        </TouchableOpacity>
      </View>

      {/* Content below player (only when not fullscreen) */}
      {!isFullscreen && (
        <ScrollView style={styles.contentScroll} showsVerticalScrollIndicator={false}>
          {/* Video title & info */}
          <View style={styles.videoInfoSection}>
            <Text style={styles.mainTitle}>{currentVideo.title}</Text>
            <TouchableOpacity
              style={styles.metaRow}
              onPress={() => setShowDescription(s => !s)}>
              <Text style={styles.metaText}>
                {currentVideo.folderName} · {currentVideo.sizeFormatted}
              </Text>
              <Text style={styles.metaText}>  {currentVideo.timeAgo}</Text>
              <Text style={styles.expandArrow}>{showDescription ? '▲' : '▼'}</Text>
            </TouchableOpacity>
            {showDescription && (
              <View style={styles.descriptionBox}>
                <Text style={styles.descriptionText}>
                  📁 File: {currentVideo.name}{'\n'}
                  📂 Location: {currentVideo.folder}{'\n'}
                  💾 Size: {currentVideo.sizeFormatted}{'\n'}
                  ⏱ Duration: {formatDuration(duration)}
                </Text>
              </View>
            )}
          </View>

          {/* Action buttons row - exact YouTube style */}
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            style={styles.actionsScroll}>
            <View style={styles.actionButtonsRow}>
              <TouchableOpacity style={styles.actionChip}>
                <Svg width="18" height="18" viewBox="0 0 24 24" fill="#FFF">
                  <Path d="M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z" />
                </Svg>
                <Text style={styles.actionText}>Like</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.actionChip}>
                <Svg width="18" height="18" viewBox="0 0 24 24" fill="#FFF">
                  <Path d="M15 3H6c-.83 0-1.54.5-1.84 1.22l-3.02 7.05c-.09.23-.14.47-.14.73v2c0 1.1.9 2 2 2h6.31l-.95 4.57-.03.32c0 .41.17.79.44 1.06L9.83 23l6.59-6.59c.36-.36.58-.86.58-1.41V5c0-1.1-.9-2-2-2zm4 0v12h4V3h-4z" />
                </Svg>
                <Text style={styles.actionText}>Dislike</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.actionChip}>
                <Svg width="18" height="18" viewBox="0 0 24 24" fill="#FFF">
                  <Path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92 1.61 0 2.92-1.31 2.92-2.92s-1.31-2.92-2.92-2.92z" />
                </Svg>
                <Text style={styles.actionText}>Share</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.actionChip}>
                <Svg width="18" height="18" viewBox="0 0 24 24" fill="#FFF">
                  <Path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z" />
                </Svg>
                <Text style={styles.actionText}>Download</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.actionChip}>
                <Svg width="18" height="18" viewBox="0 0 24 24" fill="#FFF">
                  <Path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z" />
                </Svg>
                <Text style={styles.actionText}>More</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>

          {/* Channel row */}
          <View style={styles.channelRow}>
            <View style={styles.channelAvatar}>
              <Text style={styles.avatarLetter}>
                {(currentVideo.folderName || 'V')[0].toUpperCase()}
              </Text>
            </View>
            <View style={styles.channelInfo}>
              <Text style={styles.channelName}>{currentVideo.folderName}</Text>
              <Text style={styles.channelSub}>Local Storage</Text>
            </View>
            <TouchableOpacity style={styles.subscribeBtn}>
              <Text style={styles.subscribeTxt}>Subscribe</Text>
            </TouchableOpacity>
          </View>

          {/* Divider */}
          <View style={styles.divider} />

          {/* Related videos */}
          <Text style={styles.relatedTitle}>Up Next</Text>
          {relatedVideos.slice(0, 15).map(v => (
            <RelatedVideoItem
              key={v.id}
              video={v}
              onPress={() => {
                setCurrentVideo(v);
                setCurrentTime(0);
                setDuration(0);
                setEnded(false);
                setPaused(false);
                setIsLoading(true);
              }}
            />
          ))}
          <View style={{ height: 40 }} />
        </ScrollView>
      )}
    </View>
  );
}

function RelatedVideoItem({ video, onPress }) {
  return (
    <TouchableOpacity style={styles.relatedItem} onPress={onPress} activeOpacity={0.8}>
      <View style={styles.relatedThumb}>
        <Image
          source={{ uri: video.uri }}
          style={styles.relatedThumbImg}
          onError={() => {}}
        />
        <View style={styles.relatedThumbFallback}>
          <Svg width="32" height="22" viewBox="0 0 90 63">
            <Rect x="0" y="0" width="90" height="63" rx="8" fill="#333" />
            <Path d="M 36 16 L 36 47 L 62 31.5 Z" fill="#555" />
          </Svg>
        </View>
      </View>
      <View style={styles.relatedInfo}>
        <Text style={styles.relatedTitle2} numberOfLines={2}>{video.title}</Text>
        <Text style={styles.relatedMeta}>{video.folderName}</Text>
        <Text style={styles.relatedMeta}>{video.sizeFormatted} · {video.timeAgo}</Text>
      </View>
      <TouchableOpacity style={styles.relatedMore}>
        <Text style={styles.moreDots}>⋮</Text>
      </TouchableOpacity>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0F0F0F',
  },
  fullscreenContainer: {
    backgroundColor: '#000',
  },
  playerWrapper: {
    width: SCREEN_WIDTH,
    backgroundColor: '#000',
    overflow: 'hidden',
  },
  playerFullscreen: {
    position: 'absolute',
    top: 0,
    left: 0,
    width: '100%',
    height: '100%',
    zIndex: 100,
  },
  controlsOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.4)',
    justifyContent: 'space-between',
  },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingTop: 8,
    gap: 8,
  },
  backBtn: {
    padding: 6,
  },
  playerTitle: {
    flex: 1,
    color: '#FFF',
    fontSize: 13,
    fontWeight: '500',
  },
  topBarRight: {
    flexDirection: 'row',
  },
  iconBtn: {
    padding: 6,
  },
  centerControls: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 32,
  },
  playPauseBtn: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  bottomControls: {
    paddingHorizontal: 12,
    paddingBottom: 10,
  },
  progressTrack: {
    height: 3,
    backgroundColor: 'rgba(255,255,255,0.3)',
    borderRadius: 2,
    marginBottom: 6,
    position: 'relative',
    overflow: 'visible',
  },
  progressBuffered: {
    position: 'absolute',
    top: 0,
    left: 0,
    height: '100%',
    backgroundColor: 'rgba(255,255,255,0.5)',
    borderRadius: 2,
  },
  progressPlayed: {
    position: 'absolute',
    top: 0,
    left: 0,
    height: '100%',
    backgroundColor: '#FF0000',
    borderRadius: 2,
  },
  progressThumb: {
    position: 'absolute',
    top: -5,
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#FF0000',
    marginLeft: -6,
  },
  timeRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  timeText: {
    color: '#FFF',
    fontSize: 12,
    fontWeight: '500',
  },
  loadingOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingSpinner: {
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 3,
    borderColor: 'rgba(255,255,255,0.3)',
    borderTopColor: '#FF0000',
  },
  contentScroll: {
    flex: 1,
  },
  videoInfoSection: {
    paddingHorizontal: 12,
    paddingTop: 12,
    paddingBottom: 8,
  },
  mainTitle: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
    lineHeight: 22,
    marginBottom: 6,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
  },
  metaText: {
    color: '#AAAAAA',
    fontSize: 13,
  },
  expandArrow: {
    color: '#AAAAAA',
    fontSize: 10,
    marginLeft: 6,
  },
  descriptionBox: {
    marginTop: 10,
    backgroundColor: '#272727',
    borderRadius: 8,
    padding: 12,
  },
  descriptionText: {
    color: '#CCCCCC',
    fontSize: 13,
    lineHeight: 20,
  },
  actionsScroll: {
    borderTopWidth: 0.5,
    borderTopColor: '#272727',
  },
  actionButtonsRow: {
    flexDirection: 'row',
    paddingHorizontal: 12,
    paddingVertical: 8,
    gap: 8,
  },
  actionChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#272727',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
  },
  actionText: {
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: '500',
  },
  channelRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 10,
    gap: 10,
  },
  channelAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#FF0000',
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarLetter: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: '700',
  },
  channelInfo: {
    flex: 1,
  },
  channelName: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
  },
  channelSub: {
    color: '#AAAAAA',
    fontSize: 12,
  },
  subscribeBtn: {
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
  },
  subscribeTxt: {
    color: '#0F0F0F',
    fontSize: 13,
    fontWeight: '700',
  },
  divider: {
    height: 0.5,
    backgroundColor: '#272727',
    marginHorizontal: 0,
    marginVertical: 8,
  },
  relatedTitle: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '600',
    paddingHorizontal: 12,
    marginBottom: 8,
  },
  relatedItem: {
    flexDirection: 'row',
    paddingHorizontal: 12,
    paddingVertical: 8,
    gap: 10,
  },
  relatedThumb: {
    width: 160,
    height: 90,
    borderRadius: 8,
    backgroundColor: '#1A1A1A',
    overflow: 'hidden',
    flexShrink: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
  relatedThumbImg: {
    ...StyleSheet.absoluteFillObject,
    resizeMode: 'cover',
  },
  relatedThumbFallback: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  relatedInfo: {
    flex: 1,
  },
  relatedTitle2: {
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: '500',
    lineHeight: 18,
    marginBottom: 4,
  },
  relatedMeta: {
    color: '#AAAAAA',
    fontSize: 11,
    lineHeight: 16,
  },
  relatedMore: {
    padding: 4,
  },
  moreDots: {
    color: '#AAAAAA',
    fontSize: 20,
  },
});
