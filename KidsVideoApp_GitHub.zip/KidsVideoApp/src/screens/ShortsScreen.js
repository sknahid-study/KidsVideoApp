// ShortsScreen.js
import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  Dimensions, ActivityIndicator,
} from 'react-native';
import Video from 'react-native-video';
import { useFocusEffect } from '@react-navigation/native';
import Svg, { Path } from 'react-native-svg';
import { scanAllVideos, requestStoragePermission } from '../utils/VideoUtils';
import AsyncStorage from '@react-native-async-storage/async-storage';

const { width, height } = Dimensions.get('window');
const ITEM_HEIGHT = height - 56; // Full screen minus tab bar

export default function ShortsScreen({ navigation }) {
  const [videos, setVideos] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [loading, setLoading] = useState(true);
  const viewabilityConfig = useRef({ viewAreaCoveragePercentThreshold: 60 });

  useFocusEffect(
    useCallback(() => {
      loadVideos();
    }, []),
  );

  const loadVideos = async () => {
    try {
      const cached = await AsyncStorage.getItem('video_cache');
      if (cached) {
        setVideos(JSON.parse(cached));
        setLoading(false);
      } else {
        await requestStoragePermission();
        const all = await scanAllVideos();
        setVideos(all);
        setLoading(false);
      }
    } catch (e) {
      setLoading(false);
    }
  };

  const onViewableItemsChanged = useRef(({ viewableItems }) => {
    if (viewableItems.length > 0) {
      setCurrentIndex(viewableItems[0].index);
    }
  });

  if (loading) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color="#FF0000" />
      </View>
    );
  }

  if (videos.length === 0) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center', gap: 12 }]}>
        <Text style={{ color: '#FFF', fontSize: 16 }}>No videos found</Text>
        <Text style={{ color: '#AAA', fontSize: 13 }}>Add videos to your device</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <FlatList
        data={videos}
        keyExtractor={item => item.id}
        renderItem={({ item, index }) => (
          <ShortsItem
            video={item}
            isActive={index === currentIndex}
            height={ITEM_HEIGHT}
            onOpenFull={() => navigation.navigate('VideoPlayer', { video: item, videos })}
          />
        )}
        pagingEnabled
        snapToInterval={ITEM_HEIGHT}
        decelerationRate="fast"
        showsVerticalScrollIndicator={false}
        onViewableItemsChanged={onViewableItemsChanged.current}
        viewabilityConfig={viewabilityConfig.current}
        getItemLayout={(_, index) => ({
          length: ITEM_HEIGHT,
          offset: ITEM_HEIGHT * index,
          index,
        })}
      />
    </View>
  );
}

function ShortsItem({ video, isActive, height, onOpenFull }) {
  const [paused, setPaused] = useState(false);
  const [liked, setLiked] = useState(false);

  useEffect(() => {
    if (!isActive) setPaused(true);
    else setPaused(false);
  }, [isActive]);

  return (
    <TouchableOpacity
      style={[styles.shortsItem, { height }]}
      activeOpacity={1}
      onPress={() => setPaused(p => !p)}>
      <Video
        source={{ uri: video.uri }}
        style={StyleSheet.absoluteFill}
        resizeMode="cover"
        repeat={true}
        paused={paused || !isActive}
        muted={false}
      />
      <View style={StyleSheet.absoluteFill} pointerEvents="box-none">
        {/* Right side actions */}
        <View style={styles.shortsActions}>
          <TouchableOpacity style={styles.shortsActionBtn} onPress={() => setLiked(l => !l)}>
            <Svg width="28" height="28" viewBox="0 0 24 24" fill={liked ? '#FF0000' : '#FFF'}>
              <Path d="M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z" />
            </Svg>
            <Text style={styles.shortsActionText}>{liked ? '1' : '0'}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.shortsActionBtn}>
            <Svg width="28" height="28" viewBox="0 0 24 24" fill="#FFF">
              <Path d="M21.99 4c0-1.1-.89-2-1.99-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h14l4 4-.01-18z" />
            </Svg>
            <Text style={styles.shortsActionText}>0</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.shortsActionBtn}>
            <Svg width="28" height="28" viewBox="0 0 24 24" fill="#FFF">
              <Path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92 1.61 0 2.92-1.31 2.92-2.92s-1.31-2.92-2.92-2.92z" />
            </Svg>
            <Text style={styles.shortsActionText}>Share</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.shortsActionBtn} onPress={onOpenFull}>
            <Svg width="28" height="28" viewBox="0 0 24 24" fill="#FFF">
              <Path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z" />
            </Svg>
            <Text style={styles.shortsActionText}>Full</Text>
          </TouchableOpacity>
        </View>

        {/* Bottom info */}
        <View style={styles.shortsBottom}>
          <View style={styles.shortsChannelRow}>
            <View style={styles.shortsAvatar}>
              <Text style={styles.shortsAvatarTxt}>
                {(video.folderName || 'V')[0].toUpperCase()}
              </Text>
            </View>
            <Text style={styles.shortsChannelName}>{video.folderName}</Text>
            <TouchableOpacity style={styles.shortsSubBtn}>
              <Text style={styles.shortsSubTxt}>Subscribe</Text>
            </TouchableOpacity>
          </View>
          <Text style={styles.shortsTitle} numberOfLines={2}>{video.title}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  shortsItem: { width, backgroundColor: '#000', position: 'relative' },
  shortsActions: {
    position: 'absolute',
    right: 10,
    bottom: 120,
    alignItems: 'center',
    gap: 20,
  },
  shortsActionBtn: { alignItems: 'center', gap: 4 },
  shortsActionText: { color: '#FFF', fontSize: 12, fontWeight: '600' },
  shortsBottom: {
    position: 'absolute',
    bottom: 80,
    left: 0,
    right: 70,
    paddingHorizontal: 12,
    gap: 8,
  },
  shortsChannelRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  shortsAvatar: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: '#FF0000',
    justifyContent: 'center', alignItems: 'center',
  },
  shortsAvatarTxt: { color: '#FFF', fontSize: 16, fontWeight: '700' },
  shortsChannelName: { color: '#FFF', fontSize: 14, fontWeight: '600', flex: 1 },
  shortsSubBtn: {
    borderWidth: 1.5, borderColor: '#FFF',
    paddingHorizontal: 12, paddingVertical: 6,
    borderRadius: 20,
  },
  shortsSubTxt: { color: '#FFF', fontSize: 13, fontWeight: '600' },
  shortsTitle: { color: '#FFF', fontSize: 14, lineHeight: 20 },
});
