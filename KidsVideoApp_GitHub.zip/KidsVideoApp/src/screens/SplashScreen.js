import React, { useEffect, useRef } from 'react';
import {
  View,
  Animated,
  StyleSheet,
  Easing,
  Dimensions,
} from 'react-native';
import Svg, { Rect, Path } from 'react-native-svg';

const { width, height } = Dimensions.get('window');

// YouTube Play button SVG logo
const YouTubeLogo = ({ size = 80, animated = false, scale }) => {
  return (
    <Animated.View style={animated ? { transform: [{ scale }] } : {}}>
      <Svg width={size} height={size * 0.7} viewBox="0 0 90 63">
        {/* Red rounded rectangle */}
        <Rect
          x="0"
          y="0"
          width="90"
          height="63"
          rx="14"
          ry="14"
          fill="#FF0000"
        />
        {/* White play triangle */}
        <Path
          d="M 36 16 L 36 47 L 62 31.5 Z"
          fill="#FFFFFF"
        />
      </Svg>
    </Animated.View>
  );
};

export default function SplashScreen() {
  const scaleAnim = useRef(new Animated.Value(0.8)).current;
  const opacityAnim = useRef(new Animated.Value(0)).current;
  const fadeOutAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    // YouTube splash: logo fades in, slight scale bounce
    Animated.sequence([
      Animated.parallel([
        Animated.timing(opacityAnim, {
          toValue: 1,
          duration: 400,
          easing: Easing.out(Easing.ease),
          useNativeDriver: true,
        }),
        Animated.spring(scaleAnim, {
          toValue: 1,
          tension: 80,
          friction: 8,
          useNativeDriver: true,
        }),
      ]),
      Animated.delay(1600),
      Animated.timing(fadeOutAnim, {
        toValue: 0,
        duration: 400,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  return (
    <Animated.View style={[styles.container, { opacity: fadeOutAnim }]}>
      <Animated.View
        style={[
          styles.logoContainer,
          {
            opacity: opacityAnim,
            transform: [{ scale: scaleAnim }],
          },
        ]}>
        <YouTubeLogo size={90} />
      </Animated.View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000000',
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
});
