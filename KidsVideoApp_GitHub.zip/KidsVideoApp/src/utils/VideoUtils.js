import RNFS from 'react-native-fs';
import { Platform, PermissionsAndroid } from 'react-native';

// Supported video extensions
const VIDEO_EXTENSIONS = [
  '.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv',
  '.webm', '.3gp', '.m4v', '.ts', '.mpg', '.mpeg',
  '.f4v', '.ogv', '.rm', '.rmvb', '.divx', '.xvid',
];

// Thumbnail cache
const thumbnailCache = new Map();

export const requestStoragePermission = async () => {
  if (Platform.OS !== 'android') return true;

  try {
    const androidVersion = parseInt(Platform.Version, 10);

    if (androidVersion >= 33) {
      // Android 13+
      const result = await PermissionsAndroid.requestMultiple([
        PermissionsAndroid.PERMISSIONS.READ_MEDIA_VIDEO,
        PermissionsAndroid.PERMISSIONS.READ_MEDIA_AUDIO,
      ]);
      return (
        result['android.permission.READ_MEDIA_VIDEO'] === 'granted'
      );
    } else if (androidVersion >= 30) {
      // Android 11-12
      const result = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE,
      );
      return result === PermissionsAndroid.RESULTS.GRANTED;
    } else {
      // Android 10 and below
      const result = await PermissionsAndroid.requestMultiple([
        PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE,
        PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
      ]);
      return (
        result['android.permission.READ_EXTERNAL_STORAGE'] === 'granted'
      );
    }
  } catch (err) {
    console.warn('Permission error:', err);
    return false;
  }
};

export const isVideoFile = filename => {
  const ext = filename.substring(filename.lastIndexOf('.')).toLowerCase();
  return VIDEO_EXTENSIONS.includes(ext);
};

export const formatDuration = seconds => {
  if (!seconds || isNaN(seconds)) return '0:00';
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  if (hrs > 0) {
    return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }
  return `${mins}:${secs.toString().padStart(2, '0')}`;
};

export const formatFileSize = bytes => {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
};

export const formatTimeAgo = mtime => {
  if (!mtime) return '';
  const now = new Date();
  const date = new Date(mtime);
  const diff = Math.floor((now - date) / 1000);
  if (diff < 60) return 'Just now';
  if (diff < 3600) return `${Math.floor(diff / 60)} minutes ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)} hours ago`;
  if (diff < 2592000) return `${Math.floor(diff / 86400)} days ago`;
  if (diff < 31536000) return `${Math.floor(diff / 2592000)} months ago`;
  return `${Math.floor(diff / 31536000)} years ago`;
};

export const getVideoTitle = filename => {
  // Remove extension and clean up filename
  const withoutExt = filename.replace(/\.[^/.]+$/, '');
  // Replace underscores, dots, hyphens with spaces
  return withoutExt.replace(/[_.\-]+/g, ' ').replace(/\s+/g, ' ').trim();
};

const scanDirectory = async (dirPath, results = [], depth = 0) => {
  if (depth > 5) return results; // Limit recursion depth

  try {
    const items = await RNFS.readDir(dirPath);
    for (const item of items) {
      // Skip hidden files/folders
      if (item.name.startsWith('.')) continue;

      if (item.isFile() && isVideoFile(item.name)) {
        results.push({
          id: item.path,
          path: item.path,
          uri: `file://${item.path}`,
          name: item.name,
          title: getVideoTitle(item.name),
          size: parseInt(item.size, 10),
          sizeFormatted: formatFileSize(parseInt(item.size, 10)),
          mtime: item.mtime,
          timeAgo: formatTimeAgo(item.mtime),
          folder: dirPath,
          folderName: dirPath.split('/').pop(),
          duration: 0,
          thumbnail: null,
        });
      } else if (item.isDirectory() && depth < 4) {
        // Skip system/app directories
        const skipDirs = ['Android', 'data', 'obb', 'cache', 'dalvik-cache'];
        if (!skipDirs.includes(item.name)) {
          await scanDirectory(item.path, results, depth + 1);
        }
      }
    }
  } catch (err) {
    // Directory not accessible, skip silently
  }
  return results;
};

export const scanAllVideos = async () => {
  const videosList = [];

  // Common storage paths on Android
  const storagePaths = [
    RNFS.ExternalStorageDirectoryPath, // /storage/emulated/0
    RNFS.ExternalStorageDirectoryPath + '/DCIM',
    RNFS.ExternalStorageDirectoryPath + '/Movies',
    RNFS.ExternalStorageDirectoryPath + '/Videos',
    RNFS.ExternalStorageDirectoryPath + '/Download',
    RNFS.ExternalStorageDirectoryPath + '/WhatsApp/Media/WhatsApp Video',
    RNFS.ExternalStorageDirectoryPath + '/Telegram',
    RNFS.DocumentDirectoryPath,
  ];

  // Try to find external SD card
  try {
    const extPaths = [
      '/storage/sdcard1',
      '/storage/sdcard0',
      '/mnt/sdcard',
      '/mnt/external_sd',
      '/storage/extSdCard',
    ];
    for (const extPath of extPaths) {
      const exists = await RNFS.exists(extPath);
      if (exists) {
        storagePaths.push(extPath);
        storagePaths.push(extPath + '/Movies');
        storagePaths.push(extPath + '/Videos');
        storagePaths.push(extPath + '/DCIM');
        break;
      }
    }
  } catch (e) {}

  // Scan all paths
  for (const storagePath of storagePaths) {
    try {
      const exists = await RNFS.exists(storagePath);
      if (exists) {
        await scanDirectory(storagePath, videosList, 0);
      }
    } catch (e) {}
  }

  // Deduplicate by path
  const seen = new Set();
  const unique = videosList.filter(v => {
    if (seen.has(v.path)) return false;
    seen.add(v.path);
    return true;
  });

  // Sort by most recent first
  unique.sort((a, b) => new Date(b.mtime) - new Date(a.mtime));

  return unique;
};

export const getVideosByFolder = videos => {
  const folders = {};
  videos.forEach(video => {
    const folder = video.folderName || 'Videos';
    if (!folders[folder]) {
      folders[folder] = [];
    }
    folders[folder].push(video);
  });
  return folders;
};

export const searchVideos = (videos, query) => {
  const q = query.toLowerCase().trim();
  if (!q) return videos;
  return videos.filter(
    v =>
      v.title.toLowerCase().includes(q) ||
      v.name.toLowerCase().includes(q) ||
      v.folderName.toLowerCase().includes(q),
  );
};
