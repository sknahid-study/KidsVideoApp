import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { View, Text, StyleSheet } from 'react-native';
import Svg, { Path, Rect, Circle, Polygon } from 'react-native-svg';

import HomeScreen from '../screens/HomeScreen';
import ShortsScreen from '../screens/ShortsScreen';
import SubscriptionsScreen from '../screens/SubscriptionsScreen';
import YouScreen from '../screens/YouScreen';
import VideoPlayerScreen from '../screens/VideoPlayerScreen';
import SearchScreen from '../screens/SearchScreen';
import FolderBrowserScreen from '../screens/FolderBrowserScreen';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

// SVG Icons matching YouTube exactly
const HomeIcon = ({ color, focused }) => (
  <Svg width="24" height="24" viewBox="0 0 24 24">
    {focused ? (
      <Path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z" fill={color} />
    ) : (
      <Path
        d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"
        fill="none"
        stroke={color}
        strokeWidth="1.5"
      />
    )}
  </Svg>
);

const ShortsIcon = ({ color }) => (
  <Svg width="24" height="24" viewBox="0 0 24 24">
    <Path
      d="M17.77 10.32l-1.2-.5L18 9l.5-1.2.5 1.2 1.2.5-1.2.5L18.5 11l-.73-0.68zM21 6.5l-.53-1.27L19.2 4.7l1.27-.53L21 2.9l.53 1.27 1.27.53-1.27.53L21 6.5zM15 9c-4.42 0-8 3.58-8 8s3.58 8 8 8 8-3.58 8-8-3.58-8-8-8zm0 14c-3.31 0-6-2.69-6-6s2.69-6 6-6 6 2.69 6 6-2.69 6-6 6z"
      fill={color}
    />
    <Path d="M13 10v8l5-4-5-4z" fill={color} />
  </Svg>
);

const AddIcon = () => (
  <View style={styles.addButton}>
    <Svg width="24" height="24" viewBox="0 0 24 24">
      <Path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z" fill="#FFFFFF" />
    </Svg>
  </View>
);

const SubscriptionsIcon = ({ color, focused }) => (
  <Svg width="24" height="24" viewBox="0 0 24 24">
    {focused ? (
      <Path
        d="M10 18v-2.54l4.949 2.54L10 20.54V18zM4 6h16v2H4V6zm3 4h10v2H7v-2zm3 4h4v2h-4v-2z"
        fill={color}
      />
    ) : (
      <>
        <Rect x="4" y="6" width="16" height="2" fill={color} />
        <Rect x="4" y="10" width="16" height="2" fill={color} />
        <Rect x="4" y="14" width="8" height="2" fill={color} />
        <Path d="M13 12v8l7-4-7-4z" fill={color} />
      </>
    )}
  </Svg>
);

const YouIcon = ({ color, focused }) => (
  <Svg width="24" height="24" viewBox="0 0 24 24">
    <Circle
      cx="12"
      cy="8"
      r="4"
      fill={focused ? color : 'none'}
      stroke={color}
      strokeWidth={focused ? '0' : '1.5'}
    />
    <Path
      d="M4 20c0-4 3.6-7 8-7s8 3 8 7"
      fill="none"
      stroke={color}
      strokeWidth="1.5"
    />
  </Svg>
);

function HomeTabs() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: styles.tabBar,
        tabBarActiveTintColor: '#FFFFFF',
        tabBarInactiveTintColor: '#909090',
        tabBarLabelStyle: styles.tabLabel,
        tabBarShowLabel: true,
      }}>
      <Tab.Screen
        name="Home"
        component={HomeScreen}
        options={{
          tabBarIcon: ({ color, focused }) => (
            <HomeIcon color={color} focused={focused} />
          ),
          tabBarLabel: 'Home',
        }}
      />
      <Tab.Screen
        name="Shorts"
        component={ShortsScreen}
        options={{
          tabBarIcon: ({ color }) => <ShortsIcon color={color} />,
          tabBarLabel: 'Shorts',
        }}
      />
      <Tab.Screen
        name="Create"
        component={HomeScreen}
        options={{
          tabBarIcon: () => <AddIcon />,
          tabBarLabel: '',
        }}
        listeners={({ navigation }) => ({
          tabPress: e => {
            e.preventDefault();
            navigation.navigate('FolderBrowser');
          },
        })}
      />
      <Tab.Screen
        name="Subscriptions"
        component={SubscriptionsScreen}
        options={{
          tabBarIcon: ({ color, focused }) => (
            <SubscriptionsIcon color={color} focused={focused} />
          ),
          tabBarLabel: 'Subscriptions',
        }}
      />
      <Tab.Screen
        name="You"
        component={YouScreen}
        options={{
          tabBarIcon: ({ color, focused }) => (
            <YouIcon color={color} focused={focused} />
          ),
          tabBarLabel: 'You',
        }}
      />
    </Tab.Navigator>
  );
}

export default function MainNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Main" component={HomeTabs} />
      <Stack.Screen
        name="VideoPlayer"
        component={VideoPlayerScreen}
        options={{
          presentation: 'card',
          gestureEnabled: true,
        }}
      />
      <Stack.Screen name="Search" component={SearchScreen} />
      <Stack.Screen name="FolderBrowser" component={FolderBrowserScreen} />
    </Stack.Navigator>
  );
}

const styles = StyleSheet.create({
  tabBar: {
    backgroundColor: '#0F0F0F',
    borderTopColor: '#272727',
    borderTopWidth: 0.5,
    height: 56,
    paddingBottom: 6,
    paddingTop: 6,
  },
  tabLabel: {
    fontSize: 10,
    fontWeight: '400',
  },
  addButton: {
    width: 36,
    height: 28,
    backgroundColor: 'transparent',
    borderWidth: 1.5,
    borderColor: '#AAAAAA',
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
