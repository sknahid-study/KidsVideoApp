# KidsVideoApp - YouTube-like Local Video Player

## 📱 Overview
A YouTube v21.10.496-style Android app that plays videos from device internal & external storage.
Built with React Native for parental control — only shows videos you put on the device.

## ✨ Features
- 🎬 Exact YouTube UI (splash, home feed, shorts, subscriptions, you/profile)
- 📁 Auto-scans internal + external storage for all video files
- 🎥 Full-featured video player (play/pause, seek, fullscreen, 10s skip)
- 🔍 Search videos by title, filename, or folder
- 📂 Folder browser to navigate device storage
- 🔄 Swipeable Shorts-style vertical feed
- ⚡ Cached scan results for fast startup
- 📱 Supports: MP4, MKV, AVI, MOV, WMV, FLV, WebM, 3GP, M4V, TS and more

## 🚀 Setup

### Prerequisites
- Node.js 18+
- Android Studio + Android SDK
- React Native CLI (`npm install -g react-native-cli`)
- Android device or emulator (Android 6.0+)

### Installation

```bash
# 1. Clone / extract the project
cd KidsVideoApp

# 2. Install dependencies
npm install

# 3. Install Android dependencies
cd android && ./gradlew clean && cd ..

# 4. Run on device
npx react-native run-android
```

### Additional Android Setup

Add to `android/app/build.gradle`:
```gradle
android {
    compileSdkVersion 34
    defaultConfig {
        minSdkVersion 21
        targetSdkVersion 34
    }
}
```

For react-native-video, add to `android/app/src/main/java/.../MainApplication.java`:
```java
import com.brentvatne.react.ReactVideoPackage;
// In getPackages():
new ReactVideoPackage()
```

### Permissions
The app will request storage permissions on first launch:
- Android 13+: READ_MEDIA_VIDEO
- Android 10-12: READ_EXTERNAL_STORAGE
- Android 9-: READ + WRITE_EXTERNAL_STORAGE

## 📂 Project Structure
```
src/
├── screens/
│   ├── SplashScreen.js      # YouTube-style splash with logo animation
│   ├── HomeScreen.js        # Main feed with video cards + shorts row
│   ├── ShortsScreen.js      # Vertical swipe shorts player
│   ├── VideoPlayerScreen.js # Full video player with all controls
│   ├── SubscriptionsScreen.js # Organized by folder/channel
│   ├── YouScreen.js         # Profile, history, playlists
│   ├── SearchScreen.js      # Search videos
│   └── FolderBrowserScreen.js # Browse device folders
├── navigation/
│   └── MainNavigator.js     # Bottom tabs + stack navigation
└── utils/
    └── VideoUtils.js        # Storage scanning, file utilities
```

## 🎨 Customization (change brand)
To rebrand the app:
1. **App name**: Edit `android/app/src/main/res/values/strings.xml`
2. **Logo**: Replace SVG in `SplashScreen.js` and `HomeScreen.js` (YTLogo component)
3. **Colors**: Change `#FF0000` to your color throughout
4. **Package name**: Rename `com.kidsvideoapp` in AndroidManifest.xml

## 📁 Where to put videos
The app automatically scans:
- `/storage/emulated/0/Movies/`
- `/storage/emulated/0/Videos/`
- `/storage/emulated/0/DCIM/`
- `/storage/emulated/0/Download/`
- `/storage/emulated/0/WhatsApp/Media/WhatsApp Video/`
- External SD card (auto-detected)

## 🔒 Parental Control Tips
- Only put approved videos on the device
- The app shows ONLY local files (no internet)
- Use Android's app lock to prevent uninstalling
- Enable Android's Digital Wellbeing to set time limits

## 📦 Key Dependencies
- `react-native-video` - Video playback
- `react-native-fs` - File system scanning
- `react-native-orientation-locker` - Fullscreen rotation
- `@react-navigation` - Navigation
- `@react-native-async-storage` - Video cache
